# wdtLoading - Application loading screen

### Demo

![wdtLoading gif](https://raw.githubusercontent.com/needim/wdtLoading/master/wdtLoading.gif "wdtLoading gif")

<http://ned.im/wdtLoading>